
var totalScore = 0;

$(document).ready(function(){
  $('.level').css('width', totalScore+'%')
})

setInterval(function(){
  totalScore = totalScore - 1;
  totalScore = totalScore > 0 ? totalScore : 0;
  $('.level').css('width', totalScore+'%')
}, 14400)

function changeImage(score) {
  totalScore = parseInt(score) + totalScore;
  totalScore = totalScore < 200 ? totalScore : 200;
  $('.level').css('width', totalScore+'%')
  if(totalScore <= 16){
    emoteFire();
  } else if (totalScore <= 32){
    emoteAngry();
  } else if(totalScore <= 48){
    emoteSad();
  } else if(totalScore <= 64){
    emoteHappy();
  } else if(totalScore <= 80){
    emoteSmile();
  } else if(totalScore <= 100){
    emoteGlory();
  }
};

function calculateSteps() {
  var steps = $('#steps').val();
  steps = steps ? parseInt(steps) : 0;
  changeImage((steps/10000) * 10);
};

